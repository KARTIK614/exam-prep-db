========================================
RSSB Computer Anudeshak Exam Prep Platform
========================================

Quick Start:
  1. cd exam-prep-platform
  2. bash run.sh
  3. Open http://localhost:5050

Features:
  - 1,279 bilingual MCQs (English + Hindi)
  - 42 topics across all subjects
  - Diagnostic-first: finds weak areas before practice
  - Error tracking with root cause analysis
  - Spaced repetition redo system
  - Topic mastery scoring

Requirements:
  - Python 3.10+
  - pip
  - Web browser

========================================
